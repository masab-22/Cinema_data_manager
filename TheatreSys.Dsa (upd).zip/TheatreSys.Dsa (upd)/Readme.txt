 This Dsa project generalises the basic use of (cinema data manager) by the representative
 to ensure the best requirements of a customer, As we deep dive in a visualizing first customer
 representative logins by entering his id and password then customer is shown a list of seating
 on display, to check which seats he likes to be booked then after selecting one the representative
 opens booking form takes credentials of the customer and saves his receipt. After saving his receipt
 he opens seat choose grid and selects a seat on the bases of customers requirement, Every customer
 receipt will be sorted according to alphabetical order which is also merged with a special serial
 numbers which help in eraser of overwriting txt files. Now further each frame will be explained on
 the bases of its fulfilling tasks:

1. Login Frame (Login class):
Purpose:
-Authenticates users before accessing the main system.
Key Components:
-Username and Password fields.
Login button:
-Error messages for invalid input.
Functionality:
-Validates user input.
-Navigates to the Home Page frame upon successful login.
-Handles key events for efficient navigation.


2. Home Page Frame (navigateToHomePage method in Login class):
Purpose:
-Serves as the main interface for users after login.
Key Components:
-Buttons for Total Seats, Book a Seat, Seats Left, and Sign Out.
Functionality:
-Navigates to specific frames based on button clicks.
-Displays a welcome message and options for various actions.


3. Seating Arrangement Frame (SeatingArrangementFrame class):
Purpose:
-Displays the arrangement of seats in the theater.
Key Components:
-Seat labels showing the arrangement.
Functionality:
-Differentiates between VIP and regular seats.
-Allows navigation back to the Home Page.


4. Seat Booking Frame (SeatBookingFrame class):
Purpose:
-Allows users to book seats for a particular movie.
Key Components:
-Input fields for customer name, movie selection, seat specification, and number of seats.
-Submit button for booking.
Functionality:
-Validates user input.
-Checks seat availability and books seats.
-Generates a receipt upon successful booking.


5. View Receipt Frame (ViewReceiptFrame class):
Purpose:
-Displays and optionally saves the receipt for a seat booking.
Key Components:
-Receipt information including customer name, movie, seat, seats to book, and total amount.
Functionality:
-Handles the creation and display of the receipt.
-Prompts the user to save the receipt to a file.
-Implements a file search functionality.


6. Seats Left Frame (SeatsLeftFrame class):
Purpose:
-Displays the availability of seats in the theater.
Key Components:
-Labels representing individual seats.
Functionality:
-Updates seat images based on availability.
-Allows users to book available seats with a mouse click.
-Handles VIP seat reservations and provides user feedback.

