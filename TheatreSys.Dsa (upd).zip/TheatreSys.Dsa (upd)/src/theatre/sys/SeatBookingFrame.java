package theatre.sys;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

// Frame for seat booking
public class SeatBookingFrame extends JFrame {
    private JTextField customerNameField;
    private JComboBox<String> movieComboBox;
    private JTextField rowField;
    private JTextField seatsToBookField;

    // Constructor for SeatBookingFrame
    public SeatBookingFrame(JFrame previousFrame) {
        setTitle("Seat Booking Form");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel bookingPanel = new JPanel();
        bookingPanel.setLayout(null);
        bookingPanel.setBackground(new Color(0x697086));

        // Title labels
        JLabel mainTitleLabel = new JLabel("Seat Booking");
        mainTitleLabel.setFont(new Font("Gill Sans MT", Font.PLAIN, 48));
        mainTitleLabel.setForeground(Color.WHITE);
        mainTitleLabel.setBounds(200, 20, 400, 60);
        mainTitleLabel.setHorizontalAlignment(JLabel.CENTER);

        // Text fields and combo box for user input
        customerNameField = createStyledTextField();
        customerNameField.setBounds(300, 100, 200, 30);

        movieComboBox = createMovieComboBox();
        movieComboBox.setBounds(300, 150, 200, 30);

        rowField = createStyledTextField();
        rowField.setBounds(300, 200, 200, 30);

        seatsToBookField = createStyledTextField();
        seatsToBookField.setBounds(350, 250, 150, 30);

        // Submit button with ActionListener
        JButton submitButton = createStyledButton("Submit", 300, 320, 150, 30, e -> {
            // Validate and process user input
            if (areFieldsEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields must be filled!", "Empty Fields", JOptionPane.WARNING_MESSAGE);
            } else {
                try {
                    int numSeats = Integer.parseInt(seatsToBookField.getText());
                    if (numSeats < 0) {
                        throw new NumberFormatException();
                    }

                    int seatNumber = Integer.parseInt(rowField.getText());

                    if (seatNumber < 1 || seatNumber > 12) {
                        JOptionPane.showMessageDialog(this, "Seat number must be between 1 and 12", "Invalid Row Number", JOptionPane.WARNING_MESSAGE);
                    } else {
                        // Check if the specified seat is a VIP seat
                        if (isVipSeat(seatNumber)) {
                            JOptionPane.showMessageDialog(this, "This seat is reserved for VIP guests. Choose another seat.", "VIP Seat Booking Alert", JOptionPane.WARNING_MESSAGE);
                        } else {
                            int totalPrice = numSeats * 2400; // Fixed seat price

                            // Display an alert for successful booking
                            JOptionPane.showMessageDialog(this, "Booking Approved!", "Success", JOptionPane.INFORMATION_MESSAGE);

                            // Pass user information to the homepage for later retrieval
                            String customerName = customerNameField.getText();
                            String selectedMovie = (String) movieComboBox.getSelectedItem();
                            String row = rowField.getText();
                            String seatsToBook = seatsToBookField.getText();

                            // Modified: Call a method in ViewReceiptFrame to handle the receipt with new file naming
                            ViewReceiptFrame.handleReceipt(customerName, selectedMovie, row, seatsToBook, totalPrice);
                        }
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Number of seats must be a valid positive integer", "Invalid Input", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        // Labels, separators, back button
        bookingPanel.add(mainTitleLabel);
        bookingPanel.add(createStyledLabel("Customer Name:", 100, 100, 150, 30));
        bookingPanel.add(customerNameField);
        bookingPanel.add(createStyledLabel("Movie Name:", 100, 150, 150, 30));
        bookingPanel.add(movieComboBox);
        bookingPanel.add(createStyledLabel("Specify a Seat:", 100, 200, 150, 30));
        bookingPanel.add(rowField);
        bookingPanel.add(createStyledLabel("Number of Seats to be Booked:", 100, 250, 250, 30));
        bookingPanel.add(seatsToBookField);
        bookingPanel.add(submitButton);
        bookingPanel.add(createStyledSeparator(250, 290, 300, 10));
        bookingPanel.add(createStyledButton("Back", 300, 350, 150, 30, e -> {
            dispose();  // Close the frame
            previousFrame.setVisible(true);  // Show the previous frame (homepage)
        }));

        setContentPane(bookingPanel);
    }

    // Method to check if input fields are empty
    private boolean areFieldsEmpty() {
        return customerNameField.getText().isEmpty() ||
                rowField.getText().isEmpty() ||
                seatsToBookField.getText().isEmpty();
    }

    // Method to create a field
    private JTextField createStyledTextField() {
        JTextField textField = new JTextField();
        textField.setFont(new Font("Gill Sans MT", Font.PLAIN, 16));
        textField.setBackground(new Color(0xFFD2D2D9, true));
        textField.setForeground(new Color(0x0F0F11));
        return textField;
    }

    // Method to create label
    private JLabel createStyledLabel(String text, int x, int y, int width, int height) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Gill Sans MT", Font.PLAIN, 18));
        label.setForeground(Color.WHITE);
        label.setBounds(x, y, width, height);
        return label;
    }

    // Method to create  separator
    private JSeparator createStyledSeparator(int x, int y, int width, int height) {
        JSeparator separator = new JSeparator(JSeparator.HORIZONTAL);
        separator.setBounds(x, y, width, height);
        return separator;
    }

    // Method to create button with ActionListener
    private JButton createStyledButton(String text, int x, int y, int width, int height, ActionListener listener) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0xDED864));
        button.setForeground(new Color(0x0F0F11));
        button.setFont(new Font("Gill Sans MT", Font.PLAIN, 18));
        button.setBounds(x, y, width, height);
        button.addActionListener(listener);
        return button;
    }

    // Method to create a combo box for movie selection
    private JComboBox<String> createMovieComboBox() {
        String[] movies = {"Fast X", "Ford vs Ferrari", "Shawshank Redemption", "Cars","Rush"};
        JComboBox<String> comboBox = new JComboBox<>(movies);
        comboBox.setFont(new Font("Gill Sans MT", Font.PLAIN, 16));
        comboBox.setBackground(new Color(0xFFD2D2D9, true));
        comboBox.setForeground(new Color(0x0F0F11));
        return comboBox;
    }

    // Method to check if a seat is a VIP seat
    private boolean isVipSeat(int seatNumber) {
        // Define the VIP seats (2nd seat of 1st row, 2nd seat of 2nd row, and 3rd seat of 3rd row)
        return (seatNumber == 1 || seatNumber == 2 || seatNumber == 3);
    }

    // Main method for testing the SeatBookingFrame
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame testFrame = new JFrame("Testing Seat Booking Frame");
            testFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            testFrame.setSize(400, 400);
            testFrame.setLocationRelativeTo(null);

            JButton bookingBtn = new JButton("Seat Booking");
            bookingBtn.addActionListener(e -> {
                testFrame.setVisible(false);
                SeatBookingFrame bookingFrame = new SeatBookingFrame(testFrame);
                bookingFrame.setVisible(true);
            });

            JPanel testPanel = new JPanel();
            testPanel.add(bookingBtn);

            testFrame.setContentPane(testPanel);
            testFrame.setVisible(true);
        });
    }
}
